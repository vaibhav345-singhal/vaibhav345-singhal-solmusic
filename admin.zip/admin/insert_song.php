<?php
        ob_start();
        session_start();
        include("db.php");

        if(empty($_POST["song"]) || empty($_POST["artist"]) || empty($_POST["description"]) || empty($_POST["album"])){
          header("location:song.php?empty=1"); 
		  /* echo $_POST["song"];
		   echo $_POST["description"];
		   echo $_POST["album"];
		   echo $_POST["artist"];*/
        }

        else{
            $song = $_POST["song"];
			$artist = $_POST["artist"];
            $description = $_POST["description"];
            $album_code = $_POST["album"];
			

            
			$sn=0;
			$rs=mysqli_query($conn,"select MAX(sn) from song where album_code='$album_code'");
			if($r=mysqli_fetch_array($rs)){
				$sn=$r[0];
			}
			$sn++;
			
		
			$code="";
			$a=array();
			for($i='A';$i<='Z';$i++){
				array_push($a,$i);
				if($i=='Z')
					break;
			}
			
			for($i=0;$i<=9;$i++){
				array_push($a,$i);
			}
			
			for($i='a';$i<='z';$i++){
				array_push($a,$i);
				if($i=='z')
					break;
			}
			
			$b=array_rand($a,6);
			for($i=0; $i<sizeof($b); $i++){
				$code=$code.$a[$b[$i]];
			}
			$code=$code."_".$sn;
            $status=0;

			
			$file = "D:/xamp/htdocs/MP3 project/song/$album_code/";  
			$target = $file.$code.".mp3"; 
						
			if(move_uploaded_file($_FILES['uploadFile']['tmp_name'],$target)){
			
				if(mysqli_query($conn,"insert into song values ('$sn','$code','$song',
				'$artist','$album_code','$description','$status')")>0){
							header("location:song.php?album_code=$album_code&success=1");
						}
						else{
							header("location:song.php?album_code=$album_code&queryerror=1");
						}

					}
						else{
							header("location:song.php?album_code=$album_code&uploaderror=1");
                            
						}
			}			
?>