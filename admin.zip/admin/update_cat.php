<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_POST["category"]) || empty($_REQUEST["category_code"])){
		header("location:category.php?empty=1");
		}
		else{
			$category=$_POST["category"];
            $category_code=$_REQUEST["category_code"];

			$file = "D:/xamp/htdocs/MP3 project/categoryimg/";  
                $target = $file.$code.".jpg"; 
                if(move_uploaded_file($_FILES['catimage']['tmp_name'], $target)){
            
			
						if(mysqli_query($conn,"update album_category set category_name='$category' WHERE code='$category_code'")>0){
							header("location:category.php?success=1");
						}
						else{
							header("location:category.php?error=1");
						}
				}
				else{
					header("location:category.php?img_update_error=1");
				}

		}			
?>