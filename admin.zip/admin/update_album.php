<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_REQUEST["album_code"])||  empty($_POST["album"]) || empty($_POST["description"]) || empty($_POST["category"])){
		header("location:ch_album.php?empty=1");
		}
		else{
			$album_code=$_REQUEST["album_code"];
            $album=$_POST["album"];
            $description=$_POST["description"];
            $category=$_POST["category"];
            
			    $file = "D:/xamp/htdocs/MP3 project/images/";  
                $target = $file.$album_code.".jpg"; 
                if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){
						if(mysqli_query($conn,"update album set album='$album',descriptions='$description',category_code='$category' where code='$album_code'")>0){
							header("location:ch_album.php?success=1");
						}
						else{
							header("location:ch_album.php?error=1");
						}
                }
                else{
                    header("location:ch_album.php?imgerror=1");
                }
			}
					
?>