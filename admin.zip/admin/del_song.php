<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_REQUEST["song_code"])){
		header("location:ch_song.php?empty=1");
		}
		else{
            $song_code=$_REQUEST["song_code"];
			
                if(mysqli_query($conn,"update song set status=1 where code='$song_code'")>0){
						header("location:ch_song.php?success=1");
						
                }
                else{
                    header("location:ch_song.php?error=1");
                }
		}
?>