<?php
    ob_start();
    session_start();
    include("db.php");
    if(empty($_REQUEST["song_code"]) ||empty($_POST["title"]) || empty($_POST["artist"]) || empty($_POST["description"]) || empty($_POST["album"])){
        header("location:edit_song.php?empty=1");
    }
    else{
        $song_code = $_REQUEST["song_code"];
        $title = $_POST["title"];
        $artist = $_POST["artist"];
        $description = $_POST["description"];
        $album_code = $_POST["album"];

        $file = "D:/xamp/htdocs/MP3 project/song/$album_code/";  
			$target = $file.$song_code.".mp3"; 
						
			if(move_uploaded_file($_FILES['uploadFile']['tmp_name'],$target)){

                if(mysqli_query($conn,"update song set title='$title',artist='$artist',descriptions='$description',album_code='$album_code' where code='$song_code' ")>0){
                    header("location:ch_song.php?success=1");
                }
            }
            else{
                header("location:ch_song.php?songerror=1");
            }
			
    }
?>