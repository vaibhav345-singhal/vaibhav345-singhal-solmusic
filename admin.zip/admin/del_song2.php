<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_REQUEST["song_code"])){
		header("location:ch_song.php?empty=1");
		}
		else{
            $song_code=$_REQUEST["song_code"];

			$rs = mysqli_query($conn,"select album_code from song where code='$song_code'");
			if($r = mysqli_fetch_array($rs)){
				$album_code = $r[0];
			}
			
			unlink("D:/xamp/htdocs/MP3 project/song/".$album_code."/$song_code.mp3");
			
			
                if(mysqli_query($conn,"delete from song where code='$song_code'")>0){
						header("location:ch_song.php?success=1");
						
                }
                else{
                    header("location:ch_song.php?error=1");
                }
		}
?>