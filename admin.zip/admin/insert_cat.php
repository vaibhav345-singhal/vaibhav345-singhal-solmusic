<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_POST["category"])){
			//header("location:category.php?empty=1");
			echo $_POST["category"];
		}
		else{
			$category=$_POST["category"];
			
			$sn=0;
			$rs=mysqli_query($conn,"select MAX(sn) from album_category");
			if($r=mysqli_fetch_array($rs)){
				$sn=$r[0];
			}
			$sn++;
			
		
			$code="";
			$a=array();
			for($i='A';$i<='Z';$i++){
				array_push($a,$i);
				if($i=='Z')
					break;
			}
			
			for($i=0;$i<=9;$i++){
				array_push($a,$i);
			}
			
			for($i='a';$i<='z';$i++){
				array_push($a,$i);
				if($i=='z')
					break;
			}
			
			$b=array_rand($a,6);
			for($i=0; $i<sizeof($b); $i++){
				$code=$code.$a[$b[$i]];
			}
			$code=$code."_".$sn;
            $status=0;
			$file = "D:/xamp/htdocs/MP3 project/categoryimg/";  
                $target = $file.$code.".jpg"; 
                if(move_uploaded_file($_FILES['catimage']['tmp_name'], $target)){ 
			
						if(mysqli_query($conn,"insert into album_category values('$sn','$code','$category','$status')")>0){
							header("location:album.php?success=1");
						}
						else{
							header("location:category.php?error=1");
                            
						}
				}
				else{
					header("location:category.php?img_error=1");
					
				}
		}
						
		?>