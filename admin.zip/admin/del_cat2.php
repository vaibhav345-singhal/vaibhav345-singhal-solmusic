<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_REQUEST["category_code"])){
		header("location:category.php?empty=1");
		}
		else{
            $category_code=$_REQUEST["category_code"];

            $rs=mysqli_query($conn,"select code from album where category_code='$category_code'");
            while($r=mysqli_fetch_array($rs)){
                $album_code=$r[0];
                unlink("D:/xamp/htdocs/MP3 project/categoryimg/$category_code.jpg");
            
                unlink("D:/xamp/htdocs/MP3 project/images/$album_code.jpg");
                $dirPath = "D:/xamp/htdocs/MP3 project/song/$album_code";
                if (! is_dir($dirPath)) {
                    header("location:category.php?errordeletingfile=1");
                }
                if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
                    $dirPath .= '/';
                }
                $files = glob($dirPath . '*', GLOB_MARK);
                foreach ($files as $file) {
                    if (is_dir($file)) {
                        self::deleteDir($file);
                    } else {
                        unlink($file);
                    }
                }
                rmdir($dirPath);
            }
                
						if(mysqli_query($conn,"delete from album_category  WHERE code='$category_code'")>0){
                            if(mysqli_query($conn,"delete from album where category_code='$category_code'")>0){
                                if(mysqli_query($conn,"delete from song where album_code='$album_code'")>0){
							header("location:category.php?success=1");
                                }
                                else{
                                    header("location:category.php?songerror=1");
                                }
                            }
                            else{
                                header("location:category.php?albumerror=1");
                            }
						}
						else{
							header("location:category.php?error=1");
						}
            }
            		
?>