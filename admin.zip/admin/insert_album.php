<?php 
     ob_start();
	 session_start();
	 include("db.php");
	if(empty($_POST["album"]) || empty($_POST["description"]) || empty($_POST["category"])){
		header("location:album.php?empty=1");
		
		}
		else{
            $album=$_POST["album"];
            $description=$_POST["description"];
			$category_code=$_POST["category"];
			
			$sn=0;
			$rs=mysqli_query($conn,"select MAX(sn) from album");
			if($r=mysqli_fetch_array($rs)){
				$sn=$r[0];
			}
			$sn++;
			
		
			$code="";
			$a=array();
			for($i='A';$i<='Z';$i++){
				array_push($a,$i);
				if($i=='Z')
					break;
			}
			
			for($i=0;$i<=9;$i++){
				array_push($a,$i);
			}
			
			for($i='a';$i<='z';$i++){
				array_push($a,$i);
				if($i=='z')
					break;
			}
			
			$b=array_rand($a,6);
			for($i=0; $i<sizeof($b); $i++){
				$code=$code.$a[$b[$i]];
			}
			$code=$code."_".$sn;
            $status=0;

			$file = "D:/xamp/htdocs/MP3 project/images/";  
                $target = $file.$code.".jpg"; 
                if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){ 
                        if(mkdir("D:/xamp/htdocs/MP3 project/song/".$code)){
                        
							if(mysqli_query($conn,"insert into album values('$sn','$code','$album','$description','$status','$category_code')")>0){
								header("location:song.php?success=1");
							}
							else{
									header("location:album.php?error=1");
							}
						}
						else{
							header("location:album.php?img_error=1");
						}
					}
		}
						
						
?>