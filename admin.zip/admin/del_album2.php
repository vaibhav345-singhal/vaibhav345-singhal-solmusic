<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_REQUEST["album_code"])){
		header("location:ch_album.php?empty=1");
		}
		else{
            $album_code=$_REQUEST["album_code"];

            unlink("D:/xamp/htdocs/MP3 project/images/$album_code.jpg");
            $dirPath = "D:/xamp/htdocs/MP3 project/song/$album_code";
            if (! is_dir($dirPath)) {
                header("location:category.php?errordeletingfile=1");
            }
            if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
                $dirPath .= '/';
            }
            $files = glob($dirPath . '*', GLOB_MARK);
            foreach ($files as $file) {
                if (is_dir($file)) {
                    self::deleteDir($file);
                } else {
                    unlink($file);
                }
            }
            rmdir($dirPath);
			
                            if(mysqli_query($conn,"delete from album where code='$album_code'")>0){
                                if(mysqli_query($conn,"delete from song where album_code='$album_code'")>0){
							        header("location:ch_album.php?success=1");
                                }
                                else{
                                    header("location:ch_album.php?songerror=1");
                                }
                            }
                            else{
                                header("location:ch_album.php?albumerror=1");
                            }
						}
?>