<?php
    ob_start();
    session_start();
    include("db.php");
    if(!isset($_COOKIE["email"])){
        header("location:login.php");
    }
    else{
        $email = mysqli_real_escape_string ($conn,$_COOKIE["email"]);
        if(!isset($_SESSION[$email])){
            header("location:login.php");
        }
        else if(empty($_REQUEST["album_code"]) || empty($_REQUEST["song_code"])){
            header("location:play_song.php?album_code=$album_code&song_code=$song_code&empty=1");
                /*echo $_REQUEST["album_code"];
                echo $_REQUEST["song_code"];
                echo $email;*/
        }
        else{
            $album_code = $_REQUEST["album_code"];
            $song_code = $_REQUEST["song_code"];

            $sn=0;
			$rs=mysqli_query($conn,"select MAX(sn) from fav_song");
			if($r=mysqli_fetch_array($rs)){
				$sn=$r[0];
			}
			$sn++;
			
		
			$code="";
			$a=array();
			for($i='A';$i<='Z';$i++){
				array_push($a,$i);
				if($i=='Z')
					break;
			}
			
			for($i=0;$i<=9;$i++){
				array_push($a,$i);
			}
			
			for($i='a';$i<='z';$i++){
				array_push($a,$i);
				if($i=='z')
					break;
			}
			
			$b=array_rand($a,6);
			for($i=0; $i<sizeof($b); $i++){
				$code=$code.$a[$b[$i]];
			}
			$code=$code."_".$sn;

            $rs = mysqli_query($conn,"select * from fav_song where song_code='$song_code'");
            if($r = mysqli_fetch_array($rs)){
                header("location:play_song.php?album_code=$album_code&song_code=$song_code&added=1");
            }
            else{

                if(mysqli_query($conn,"insert into fav_song values('$sn','$code','$email','$album_code','$song_code')")>0){
                    header("location:play_song.php?album_code=$album_code&song_code=$song_code&success=1");
                }
                else{
                    header("location:play_song.php?album_code=$album_code&song_code=$song_code&error=1");
                }
            }
        }
    }
?>