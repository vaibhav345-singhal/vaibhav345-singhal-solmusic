<?php
ob_start();
session_start();
include("db.php");
if(!isset($_COOKIE["email"])){
	header("location:login.php");
}
else{
	$email = mysqli_real_escape_string ($conn,$_COOKIE["email"]);
	if(!isset($_SESSION[$email])){
		header("location:login.php");
	}
	if(empty($_REQUEST["album_code"]) || empty($_REQUEST["song_code"])){
		header("location:index.php?empty_code=1");
	}
	else{
		$album_code= $_REQUEST["album_code"];
		$song_code = $_REQUEST["song_code"];
	}
	if(isset($_GET["error"])){
		echo '<script type="text/javascript"> alert("Try Again")</script>';
	}
	if(isset($_GET["added"])){
		echo '<script type="text/javascript"> alert("Already Added to favourites")</script>';
	}
	if(isset($_GET["success"])){
		echo '<script type="text/javascript"> alert("Added to favourites")</script>';
	}
?>





<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>SolMusic</title>
	<meta charset="UTF-8">
	<meta name="description" content="SolMusic HTML Template">
	<meta name="keywords" content="music, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i&display=swap" rel="stylesheet">
 
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section clearfix">
		<a href="index.php" class="site-logo">
			<img src="img/logo.png" alt="">
		</a>
		
		<ul class="main-menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="category.php">Genres</a></li>
			<li><a href="favourite.php">Favourites</a></li>
			<li><a href="category.php">Albums</a></li>
			<li><a href="logout.php">Logout</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
	</header>
	<!-- Header section end -->

	<!-- Player section -->
	<?php
			$rs = mysqli_query($conn,"select* from song where code='$song_code' AND status=0");
			if($r = mysqli_fetch_array($rs)){
	?>
	<section class="player-section set-bg" data-setbg="images/<?=$album_code?>.jpg">
		<div class="player-box">
			<div class="tarck-thumb-warp">
				<div class="tarck-thumb">
					<img src="images/<?=$album_code?>.jpg" height="200" width="300" alt="">
					<button onclick="wavesurfer.playPause();" class="wp-play"></button>
				</div>
			</div>
			<div class="wave-player-warp">
				<div class="row">
					<div class="col-lg-8">
						<div class="wave-player-info">
							<h2><?=$r["title"]?></h2>
							<p><?=$r["artist"]?></p>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="songs-links">
							
							<a href="insert_fav.php?album_code=<?=$album_code?>&song_code=<?=$song_code?>"><i class='fa fa-heart'  id="heart" style='font-size:25px;color:red'></i></a>							 
						</div>
					</div>
					
				</div>
				<div id="wavePlayer" class="clierfix">
					<div id="audiowave" data-waveurl="song/<?=$album_code?>/<?=$song_code?>.mp3"></div>
					<div id="currentTime"></div>
					<div id="clipTime"></div>
					<!-- Player Controls -->
					<div class="wavePlayer_controls">
						<button class="jp-prev player_button" onclick="wavesurfer.skipBackward();"></button>
						<button class="jp-play player_button" onclick="wavesurfer.playPause();"></button>
						<button class="jp-next player_button" onclick="wavesurfer.skipForward();"></button>
						<button class="jp-stop player_button" onclick="wavesurfer.stop();"></button>
					</div>
				</div>
			</div>
		</div>
	</section>
    <?php
            }
            ?>
	<!-- Player section end -->

			<!-- Songs details section -->
			<section class="songs-details-section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-7">
					<div class="song-details-box">
						<h3>Song Details</h3>
						<?php
						$rs = mysqli_query($conn,"select * from song where code = '$song_code'");
						if($r = mysqli_fetch_array($rs)){
						
						?>
						<p><b>Description:</b><br><?=$r["descriptions"]?></p>
					</div>
				</div>

				<div class="col-lg-5">
					<div class="row">
							<div class="song-details-box">
								<h3>About the Artist</h3>
								<div class="artist-details">
									<img src="img/artist.jpg" alt="">
									<div class="ad-text">
										<h5><?=$r["artist"]?></h5>
									</div>
								<?php
									}
								?>

								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Songs details section -->

	
	<!-- Similar Songs section -->
	<section class="similar-songs-section">
		<div class="container-fluid">
			<h3>Similar Songs</h3>
			<div class="row">
			
			<?php
			$rs = mysqli_query($conn,"select * from song where code!='$song_code' AND album_code='$album_code' AND status=0");
			while($r = mysqli_fetch_array($rs)){

            ?>
			
					<div class="col-md-4">
						<div class="category-item">
							<img src="images/<?=$r["album_code"]?>.jpg" height="200" width="300" alt="">
							<div class="ci-text">
								<h4><?=$r["title"]?></h4>
								<p><?=$r["artist"]?></p>
							</div>
							
							<a href="play_song.php?album_code=<?=$r["album_code"]?>&song_code=<?=$r["code"]?>" class="ci-link"><i class="fa fa-play"></i></a>
						</div>
					</div>

				<?php
					}
				?>
			</div>
		</div>
	</section>
	<!-- Similar Songs section end -->
	<div>



	<!-- <audio id="myplayer" autoplay controls><source src="song/<?=$album_code?>/<?=$song_code?>.mp3" type="audio/mp3">
	</audio>
	</div> -->
	

	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-6 col-lg-7 order-lg-2">
					<div class="row">
						<div class="col-sm-4">
							<div class="footer-widget">
								<h2>About us</h2>
								<ul>
									<li><a href="">Our Story</a></li>
									<li><a href="">Sol Music Blog</a></li>
									<li><a href="">History</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="footer-widget">
								<h2>Products</h2>
								<ul>
									<li><a href="">Music</a></li>
									<li><a href="">Subscription</a></li>
									<li><a href="">Custom Music</a></li>
									<li><a href="">Footage</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="footer-widget">
								<h2>Playlists</h2>
								<ul>
									<li><a href="">Newsletter</a></li>
									<li><a href="">Careers</a></li>
									<li><a href="">Press</a></li>
									<li><a href="">Contact</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-6 col-lg-5 order-lg-1">
					<img src="img/logo.png" alt="">
					<div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
					<div class="social-links">
						<a href=""><i class="fa fa-instagram"></i></a>
						<a href=""><i class="fa fa-pinterest"></i></a>
						<a href=""><i class="fa fa-facebook"></i></a>
						<a href=""><i class="fa fa-twitter"></i></a>
						<a href=""><i class="fa fa-youtube"></i></a>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer section end -->
	
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/main.js"></script>

	<!-- Audio Players js -->
	<script src="js/jquery.jplayer.min.js"></script>
	<script src="js/wavesurfer.min.js"></script>

	<!-- Audio Players Initialization -->
	<script src="js/WaveSurferInit.js"></script>
	<script src="js/jplayerInit.js"></script>

	<!-- <script>
    function change(music){
	document.getElementById("myplayer").setAttribute('src',music);
		
    }
	</script> -->
	
	
	

	</body>
</html>
<?php

	}
	
	?>