<?php 
     ob_start();
	 session_start();
	 include("db.php");
	 	if(empty($_POST["fname"]) ||empty($_POST["lname"]) || empty($_POST["email"]) || empty($_POST["pass"])|| empty($_POST["cpass"])){
		header("location:register.php?empty=1");
		}
		else{
			$fname=$_POST["fname"];
            $lname=$_POST["lname"];
			$email=$_POST["email"];
            $pass=$_POST["pass"];
            $cpass=$_POST["cpass"];

            if($pass == $cpass){			
                        $sn=0;
                        $rs=mysqli_query($conn,"select MAX(sn) from users");
                        if($r=mysqli_fetch_array($rs)){
                            $sn=$r[0];
                        }
                        $sn++;
                        
                    
                        $code="";
                        $a=array();
                        for($i='A';$i<='Z';$i++){
                            array_push($a,$i);
                            if($i=='Z')
                                break;
                        }
                        
                        for($i=0;$i<=9;$i++){
                            array_push($a,$i);
                        }
                        
                        for($i='a';$i<='z';$i++){
                            array_push($a,$i);
                            if($i=='z')
                                break;
                        }
                        
                        $b=array_rand($a,6);
                        for($i=0; $i<sizeof($b); $i++){
                            $code=$code.$a[$b[$i]];
                        }
                        $code=$code."_".$sn;

                        if(mysqli_query($conn,"insert into users values('$sn','$code','$fname','$lname','$email','$pass','$cpass')")>0){
                            header("location:login.php?success=1");
                        }
                        else{
                            header("location:register.php?error=1");
                        }

			}
            else{
                header("location:register.php?pass_error=1");
            }
    }
?>