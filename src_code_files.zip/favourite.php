<?php
ob_start();
session_start();
include("db.php");
if(!isset($_COOKIE["email"])){
	header("location:login.php");
}
else{
	$email = mysqli_real_escape_string ($conn,$_COOKIE["email"]);
	if(!isset($_SESSION[$email])){
		header("location:login.php");
	}
	if(isset($_GET["error"])){
		echo '<script type="text/javascript"> alert("Try Again")</script>';
	}
	if(isset($_GET["success"])){
		echo '<script type="text/javascript"> alert("Removed from favourites")</script>';
	}
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>SolMusic</title>
	<meta charset="UTF-8">
	<meta name="description" content="SolMusic HTML Template">
	<meta name="keywords" content="music, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i&display=swap" rel="stylesheet">
 
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section clearfix">
		<a href="index.php" class="site-logo">
			<img src="img/logo.png" alt="">
		</a>
		<ul class="main-menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="category.php">Genres</a></li>
			<li><a href="favourite.php">Favourites</a></li>
			<li><a href="category.php">Albums</a></li>
			<li><a href="logout.php">Logout</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
	</header>
	<!-- Header section end -->

	
	<!-- Category section -->
	
	<section class="category-section spad">
		<div class="container-fluid">
			<div class="section-title">
				<h3>Here Is Your Favourite Song List</h3>
			</div>
			<div class="container">
				<div class="category-links">
					<a href="category.php" class="active">Go to album</a>
				</div>
			</div>
			
			<div class="category-items">
				


			<div class="row">
			<?php
			$rs = mysqli_query($conn,"select * from fav_song where email='$email'");
			while($r = mysqli_fetch_array($rs)){
				$album_code = $r["album_code"];
				$song_code = $r["song_code"];
				$rt = mysqli_query($conn,"select * from song where album_code='$album_code' AND code='$song_code' AND status=0");
				if($t = mysqli_fetch_array($rt)){
			?>
					<div class="col-md-4">
						<div class="category-item">
							<img src="images/<?=$r["album_code"]?>.jpg" height="200"
							width="300"alt="">
							<div class="ci-text">
								<h4><?=$t["title"]?></h4>
								<h5 class="newh5"><?=$t["artist"]?></h5>
							</div>
							
							<a href="remove.php?song_code=<?=$song_code?>"><i class="fa fa-trash" style="font-size:25px;color:red;"></i></a>
							<a href="play_song.php?album_code=<?=$t["album_code"]?>&song_code=<?=$t["code"]?>" class="ci-link"><i class="fa fa-play"></i></a>
						</div>
					</div>
					<?php
						}
					}
					?>
					</div>
				</div>
		</div>
	</section>
	<!-- Category section end -->

	<!-- Songs section  -->
	
			<!-- song -->
			
			<!-- song -->
			
			<!-- song -->
			
			<!-- song -->
			
			<!-- song -->
			
			<!-- song -->
			
			<!-- song -->
			
		</div>
	</section>
	<!-- Songs section end -->

	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-6 col-lg-7 order-lg-2">
					<div class="row">
						<div class="col-sm-4">
							<div class="footer-widget">
								<h2>About us</h2>
								<ul>
									<li><a href="">Our Story</a></li>
									<li><a href="">Sol Music Blog</a></li>
									<li><a href="">History</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="footer-widget">
								<h2>Products</h2>
								<ul>
									<li><a href="">Music</a></li>
									<li><a href="">Subscription</a></li>
									<li><a href="">Custom Music</a></li>
									<li><a href="">Footage</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="footer-widget">
								<h2>Playlists</h2>
								<ul>
									<li><a href="">Newsletter</a></li>
									<li><a href="">Careers</a></li>
									<li><a href="">Press</a></li>
									<li><a href="">Contact</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-6 col-lg-5 order-lg-1">
					<img src="img/logo.png" alt="">
					<div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
					<div class="social-links">
						<a href=""><i class="fa fa-instagram"></i></a>
						<a href=""><i class="fa fa-pinterest"></i></a>
						<a href=""><i class="fa fa-facebook"></i></a>
						<a href=""><i class="fa fa-twitter"></i></a>
						<a href=""><i class="fa fa-youtube"></i></a>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer section end -->
	
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/main.js"></script>

	<!-- Audio Player and Initialization -->
	<script src="js/jquery.jplayer.min.js"></script>
	<script src="js/jplayerInit.js"></script>

	</body>
</html>
<?php
	}
?>