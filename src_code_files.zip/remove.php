<?php
    ob_start();
    session_start();
    include("db.php");
    if(empty($_REQUEST["song_code"])){
        header("location:favourite.php?empty=1");
    }
    else{
        $song_code = $_REQUEST["song_code"];

        if(mysqli_query($conn,"delete from fav_song where song_code='$song_code'")>0){
            header("location:favourite.php?success=1");
        }
        else{
            header("location:favourite.php?error=1");
        }
    }
?>